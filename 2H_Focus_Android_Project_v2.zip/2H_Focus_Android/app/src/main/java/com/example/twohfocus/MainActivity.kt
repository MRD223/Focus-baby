package com.example.twohfocus

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Typeface
import android.view.Gravity

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("focus", MODE_PRIVATE) }
    private val packages = listOf(
        "com.instagram.android" to "إنستجرام",
        "com.facebook.katana" to "فيسبوك",
        "com.zhiliaoapp.musically" to "تيك توك"
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "2H Focus"
            textSize = 30f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        layout.addView(title)
        val subtitle = TextView(this).apply {
            text = "تحكّم في وقت السوشيال ميديا"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        layout.addView(subtitle)
        val info = TextView(this).apply {
            text = "اختر التطبيقات التي تريد تحديد استخدامها بساعتين يوميًا (وقت مشترك بينها)."
            textSize = 16f
            setPadding(0, 8, 0, 16)
        }
        layout.addView(info)
        packages.forEach { (pkg, label) ->
            val cb = CheckBox(this).apply {
                text = label
                textSize = 18f
                isChecked = prefs.getBoolean(pkg, pkg == "com.instagram.android")
                setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(pkg, checked).apply() }
            }
            layout.addView(cb)
        }
        val status = TextView(this).apply {
            text = "الحد اليومي: ساعتان إجمالًا للتطبيقات المختارة."
            textSize = 15f
            setPadding(0, 20, 0, 16)
        }
        layout.addView(status)
        val access = Button(this).apply {
            text = "تفعيل صلاحية إمكانية الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(access)
        val help = TextView(this).apply {
            text = "بعد فتح الإعدادات، فعّل خدمة 2H Focus. ارجع للتطبيق واترك الخدمة مفعّلة ليتم حساب وقت الاستخدام."
            textSize = 14f
            setPadding(0, 14, 0, 0)
        }
        layout.addView(help)
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
