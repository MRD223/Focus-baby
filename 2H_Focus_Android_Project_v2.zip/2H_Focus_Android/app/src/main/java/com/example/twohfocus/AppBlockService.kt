package com.example.twohfocus

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import java.time.LocalDate

class AppBlockService : AccessibilityService() {
    private val targets = setOf(
        "com.instagram.android",
        "com.facebook.katana",
        "com.zhiliaoapp.musically"
    )
    private var currentTarget: String? = null
    private var lastStart = 0L
    private var blockScreenOpen = false
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            val pkg = currentTarget
            if (pkg != null) {
                val now = System.currentTimeMillis()
                val elapsed = (now - lastStart).coerceAtLeast(0L)
                if (selected(pkg) && elapsed > 0L) {
                    saveUsed(usedToday() + elapsed)
                }
                lastStart = now
                if (usedToday() >= DAILY_LIMIT && !blockScreenOpen) {
                    showBlockScreen()
                }
            }
            handler.postDelayed(this, 1000L)
        }
    }

    companion object {
        private const val DAILY_LIMIT = 2 * 60 * 60 * 1000L
    }

    private fun prefs() = getSharedPreferences("focus", MODE_PRIVATE)
    private fun dayKey() = LocalDate.now().toString()
    private fun selected(pkg: String): Boolean =
        prefs().getBoolean(pkg, pkg == "com.instagram.android")

    private fun usedToday(): Long = prefs().getLong("used_${dayKey()}", 0L)
    private fun saveUsed(value: Long) {
        prefs().edit().putLong("used_${dayKey()}", value).apply()
    }

    private fun settleCurrent(now: Long) {
        val pkg = currentTarget ?: return
        val elapsed = (now - lastStart).coerceAtLeast(0L)
        if (selected(pkg) && elapsed > 0L) saveUsed(usedToday() + elapsed)
        currentTarget = null
    }

    private fun showBlockScreen() {
        if (blockScreenOpen) return
        blockScreenOpen = true
        val intent = Intent(this, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val now = System.currentTimeMillis()
        if (pkg in targets && selected(pkg)) {
            if (currentTarget != pkg) {
                settleCurrent(now)
                currentTarget = pkg
                lastStart = now
            }
            if (usedToday() >= DAILY_LIMIT) showBlockScreen()
        } else {
            settleCurrent(now)
            if (pkg != packageName) blockScreenOpen = false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.post(ticker)
    }

    override fun onInterrupt() {}
    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        settleCurrent(System.currentTimeMillis())
        super.onDestroy()
    }
}
