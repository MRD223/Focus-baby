package com.example.twohfocus

import android.app.Activity
import android.os.Bundle
import android.widget.*
import android.view.Gravity

class BlockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "خلص وقتك لليوم ✋"
            textSize = 28f
            gravity = Gravity.CENTER
        })
        layout.addView(TextView(this).apply {
            text = "استهلكت الساعتين المخصصين للتطبيقات المختارة. ارجع بكرة وابدأ من جديد."
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 24)
        })
        layout.addView(Button(this).apply {
            text = "إغلاق"
            setOnClickListener { finish() }
        })
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() { finish() }
}
